# Учебный проект «Код и Магия» [![Build status][travis-image]][travis-url]

* Студент: [Рустам Ашуров](https://up.htmlacademy.ru/javascript/11/user/491453).

---

_Не удаляйте и не обращайте внимание на папки и файлы:_<br>
_`.editorconfig`, `.eslintrc`, `.gitattributes`, `.gitignore`, `.travis.yml`, `package.json`._

---

<a href="https://htmlacademy.ru/intensive/javascript"><img align="left" width="50" height="50" title="HTML Academy" src="https://up.htmlacademy.ru/static/img/intensive/javascript/logo-for-github.svg"></a>

Репозиторий создан для обучения на интенсивном онлайн‑курсе «[Базовый JavaScript](https://htmlacademy.ru/intensive/javascript)» от [HTML Academy](https://htmlacademy.ru).

[travis-image]: https://travis-ci.org/htmlacademy-javascript/491453-code-and-magick.svg?branch=master
[travis-url]: https://travis-ci.org/htmlacademy-javascript/491453-code-and-magick
